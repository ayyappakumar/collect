// JavaScript Document

function showOfForm(){
var x = document.forms["formsa"];

for (var i=0;i<x.length;i++)
  {
  alert(x.elements[i].value);
  console.log(x.elements[i].getAttribute('data-num'));
  x.elements[i].setAttribute('id','otherclass');
  }
}
window.onload = showOfForm;
//    var elms = [frm1]['elements'], maxI = elms.length;
//    for(var i = 0; i < maxI; ++i) {
//    var elm = elms[i];
//    alert("Type: " + elm.type + "\nName: " +
//    elm.name + "\nId: " + elm.id);
//    }

// var mydiv = document.forms['forms'].elements;
//var mydiv = document.getElementById('forms').childNodes;
 //var mydiv = document.getElementById('forms').getElementsByTagName('input');
//var h=0;
//var c = [];
//var i;
// for(i=0; i>=3; i++){
//	 c[h] = mydiv[i];
//	 alert(c[h]);
//	  h++;
//	 }
//alert(mydiv);
// var brand = mydiv.getAttribute("data-num")
// alert(brand);
//if(brand === 'number'){
//	this.setAttribute("id", "mazda"); 
//	}
//var mydiv1=document.getElementById('mazda').onblur=function(){
//	alert(this.id);
//	}	