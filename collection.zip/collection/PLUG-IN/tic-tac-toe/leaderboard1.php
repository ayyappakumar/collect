<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">

  <!-- Use the .htaccess and remove these lines to avoid edge case issues.
       More info: h5bp.com/b/378 -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>Leaderboard | Modavigil</title>
  <meta name="description" content=""><!--120 word description for SEO purposes goes here.-->
  <meta name="keywords" content=""><!--Keywords to help with SEO go here..-->
  
  <META NAME="robots" CONTENT="noindex,nofollow,noarchive" /><!--All sites in development should not be searchable or cached. THIS MUST BE REMOVED ON GO-LIVE.-->
  <META NAME="GOOGLEBOT" CONTENT="NOARCHIVE"/><!--All sites in development should not be searchable or cached. THIS MUST BE REMOVED ON GO-LIVE.-->
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache"/><!--All sites in development should not be searchable or cached. THIS MUST BE REMOVED ON GO-LIVE.-->

  <!-- Mobile viewport optimized: j.mp/bplateviewport -->
  <meta name="viewport" content="width=device-width,initial-scale=1"><!--Related to responsive design.-->
  <meta name="viewport" content="initial-scale=1, maximum-scale=1"><!--Related to responsive design.-->

  <!-- Place favicon.ico and apple-touch-icon.png in the root directory: mathiasbynens.be/notes/touch-icons -->
  <link rel="shortcut icon" href="favicon.ico" />

  <!-- CSS: implied media=all -->
  <!-- CSS concatenated and minified via ant build script-->
  <link rel="stylesheet" media="screen" href="css/style.css" >
  <!-- end CSS-->

  <!-- More ideas for your <head> here: h5bp.com/d/head-Tips -->

  <!-- All JavaScript at the bottom, except for Modernizr / Respond.
       Modernizr enables HTML5 elements & feature detects; Respond is a polyfill for min/max-width CSS3 Media Queries
       For optimal performance, use a custom Modernizr build: www.modernizr.com/download/ -->
  <script src="js/libs/modernizr-2.0.6.min.js"></script>
  <script src="js/libs/jquery-1.8.2.min.js"></script>
<script src="js/libs/leaderBoard.js"></script>
</head>

<body>
  <div id="top_bar"></div>
  <div class="lb_content_wrapper" dir="ltr">
      <a id="lb_logo" href="index.php"><img src="img/logo_small.png"/></a>
      <div class="lb_content" dir="ltr">
          <p id="lb_header">Leaderboard Wednesday/Thursday</p>
          <table id ='leaderboard'>
              
          </table>
          <div id="winner" class="btn"><input type="button" value="winner"/></div>
          <div id ="pager">
           <p id="prev_arrow"><a href="">previous</a></p>
           <p id="page_num"><span id='dynamic_page_number'><span></p> <!-- need to give position to both of p and span -->
           <p id="next_arrow"><a href="">next</a></p> 
            </div>
      </div> <!--! end of lb_content -->
      <div id="select_winner">
          <p><b>You are about to choose the winner for this quiz.</b></p>
          <p>Do you want close the current quiz and show the winner?</p>
          <div id="sel_win" class="btn"><a href="winner.php">select winner</a></div>
      </div>
         
  </div> <!--! end of content_wrapper -->
  
  <!-- JavaScript at the bottom for fast page loading -->

  <!-- Grab Google CDN's jQuery, with a protocol relative URL; fall back to local if offline -->
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="js/libs/jquery-1.8.2.min.js"><\/script>')</script>

  <!-- scripts concatenated and minified via ant build script-->
  
  <script defer src="js/script.js"></script>
  <script src="js/respond.js"></script><!-- Responsive support for IE -->
  <!-- end scripts-->

  <!-- Change UA-XXXXX-X to be your site's ID -->
  <script>
    window._gaq = [['_setAccount','UAXXXXXXXX1'],['_trackPageview'],['_trackPageLoadTime']];
    Modernizr.load({
      load: ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js'
    });
  </script>

  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you want to support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7 ]>
    <script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
    <script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
  <![endif]-->
    
</body>
</html>
