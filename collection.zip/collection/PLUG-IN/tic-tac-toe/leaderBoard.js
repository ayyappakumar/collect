var start = 0;
var offset = 10;
var current_page = 0;
var last_page=0 ;
var slide = 0;
var change_slide= 0;
function setVars(){
  last_page = $('.anchor_page:last').children('a').attr('val');
          slide = last_page -5 ;
          change_slide = slide;
           $(".anchor_page:first a").css({'color':'black','cursor':'normal'});
}
$(document).ready(function(){
    $.ajax({
        type : 'POST', 
        url : 'setPaging.php',
        datatype : 'html',
        data: {start :start, offset: offset},
        success : function(data){
            $('#leaderboard').html(data);
        }
    });
    $.ajax({
        type : 'POST', 
        url : 'setPagingAnchors.php',
        datatype : 'html',
        data: {start :start, offset: offset},
        success : function(data){
            $('#dynamic_page_number').html(data);
            setVars();
        }
    });
});
$('.anchor_page a').live("click",function(e){
    e.preventDefault();
    current_page = $(this).attr('val') -1;
    start = current_page * offset;
    $(this).css({'color':'black','cursor':'normal'});
    $(this).parent().siblings('.anchor_page').find('a').css({'color':'#0081A4','cursor':'pointer'});
    $.ajax({
        type : 'POST', 
        url : 'setPaging.php',
        datatype : 'html',
        data: {start :start, offset: offset},
        success : function(data){ 
            $('#leaderboard').html("");
            $('#leaderboard').html(data);
        }
    });
});
$('#next_arrow a').live("click",function(e){
    e.preventDefault();
    if(slide > 0)
    {
        if(change_slide > 0)
        {
            $('#dynamic_page_number').animate({left: '-=34'}, 50);
            change_slide--;
	}
    }
    if(current_page < last_page-1)
    {
        $('a[val="'+(current_page+2)+'"]').css('color','black');
        $('.anchor_page a').not('a[val="'+(current_page+2)+'"]').css('color','#0081A4');
        start = parseInt(start) + parseInt(offset);
        current_page++;
        $.ajax({
            type : 'POST', 
            url : 'setPaging.php',
            datatype : 'html',
            data: {start :start, offset: offset},
            success : function(data){ 
                $('#leaderboard').html("");
                $('#leaderboard').html(data);
            }
        });
    }
});
$('#prev_arrow a').live("click",function(e){
    e.preventDefault();
    if(slide > 0)
    {
        if(change_slide < slide )
        {
            $('#dynamic_page_number').animate({left: '+=34'}, 50);
            change_slide++;
	} 
        if(current_page > 0)
        {
            $('a[val="'+(current_page)+'"]').css('color','black');
            $('.anchor_page a').not('a[val="'+(current_page)+'"]').css('color','#0081A4');
            start = start - offset ;
            current_page--;
            $.ajax({
                type : 'POST', 
                url : 'setPaging.php',
                datatype : 'html',
                data: {start :start, offset: offset},
                success : function(data){ 
                    data1 = data;
                    $('#leaderboard').html("");
                    $('#leaderboard').html(data1);
                }
            });
        }
    }
    });
    $(window).resize(function(){
        var currentWidth = $(window).width();
        if(currentWidth <= 768)
        {
            offset = 20;
            $.ajax({
                type : 'POST',
                url : 'setPaging.php',
                datatype : 'html',
                data: {start :start, offset: offset},
                success : function(data){
                    $('#leaderboard').html("");
                    $('#leaderboard').html(data);
                }
            });
            $.ajax({
                type : 'POST', 
                url : 'setPagingAnchors.php',
                datatype : 'html',
                data: {start :start, offset: offset},
                success : function(data){
                    $('#dynamic_page_number').html("");
                    $('#dynamic_page_number').html(data);
                    setVars();
                }
            });
                 }
        else
        {
            offset = 10;
            $.ajax({
                type : 'POST', 
                url : 'setPaging.php',
                datatype : 'html',
                data: {start :start, offset: offset},
                success : function(data){
                    $('#leaderboard').html("");
                    $('#leaderboard').html(data);
                }
            });
            $.ajax({
                type : 'POST',
                url : 'setPagingAnchors.php',
                datatype : 'html',
                data: {start :start, offset: offset},
                success : function(data){
                    $('#dynamic_page_number').html("");
                    $('#dynamic_page_number').html(data);
                    setVars();
                }
            });
            
        }
    });
    window.setTimeout('location.reload()', 360000);