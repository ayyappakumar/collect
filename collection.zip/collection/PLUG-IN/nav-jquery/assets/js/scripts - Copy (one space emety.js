(function($){
  // home page -------------------------------------------------------------- /
  
  /* --------------------menu functionality--------------------------- */
//   var containeroWidth = $('#nav').width();
//   var containerpadWidth = $('#nav').css('padding');
//   alert(containerpadWidth)
  var containerWidth = $('#nav_inner').width();
  //alert(containerWidth);
  var $navlist = $('#nav_inner').children('li')
  var listAll = $navlist.size();
  //alert(a);
     
  
  var m = [];
  var listVal = [];
  var g = 0;
  var s = 0;
  var lv = 0;
  var count = 0;
  $navlist.each(function () {
          m[g] = $(this).outerWidth();
           listVal[lv] = $(this).text();
          //alert(m[g]);
          s +=m[g];
//          alert('listVal[lv] ' + listVal[lv]);
        g++; 
        lv++;
        //if(s < containerWidth){
  //alert(s);
  //count++;
  //alert(count);
//}
    });
    console.log(listVal)
    var b;
    for (var w = 0; w < listAll; w++) {
        for (var E = 0; E < listAll; E++) {
            if (m[E] > m[E + 1]) {
                b = m[E];
                m[E] = m[E + 1];
                m[E + 1] = b
            }
        }
    }
 var maxWidth =  m[listAll - 1];
 
$navlist.css('width',maxWidth); 
//alert(containerWidth);
//alert(maxWidth);
 var colm = Math.floor((containerWidth/(maxWidth + 2)));
   alert('colm' + colm)
    //alert(listAll);
    //alert((listAll/colm)+.50);
    var row =Math.round((listAll/colm)+.50);
   console.log('row' + row);
//  alert(listAll);
 var alloElem = (row*colm);
//  alert(colm/2);
//  alert((row*colm)-(colm/2));
    //var y = m.length;
   
    //alert(listVal[0]);
//    var lasts = [];
    var c = 0;
    var fc = 0;
    var ds = 1;
    
//    
$('#nav_inner').find('li').text(" ");
    $navlist.each(function () {      
//    var sc = 0;
//for(var o=0; o<colm; o++){
//if(listAll == alloElem || listAll == (alloElem - 1) ){
if(fc <= colm){
  
console.log(ds);

console.log(c);

console.log(' listVal ' + listVal[c]);

//if(listVal[c] == "") {
//  $(this).text(" ");
//}
  
$(this).text(listVal[c]);

 c = c + row;
  fc = fc +1;
if(fc == colm){
  c = 0;
  fc = 0;
  c = ds + c;
  ds = ds + 1;
}
//}
}
//else {
//  if(fc <= colm){
//  
//console.log(ds);
//
//console.log(c);
//
//console.log(' listVal ' + listVal[c]);
//
//if(listVal[c] == "undefined") {
//  $(this).text(" ");
//}
//  
//$(this).text(listVal[c]);
//
// c = c + row;
//  fc = fc +1;
//if(fc == colm){
//  c = 0;
//  fc = 0;
//  c = ds + c;
//  ds = ds + 1;
//}
//}
//}
    });
//    var co = 0;
//    
//      for(var arr1=0; arr1<=listAll; arr1++){
//for(var arr=0; arr<listAll; arr = arr + colm){
// console.log(arr1 + "arr1")
// console.log(arr+ "arr")
//if(arr1 == arr){      
//  $navlist.eq(arr1).text(listVal[co]+ "hii");
//  console.log(co + "co")
//  co = co +1;
////  alert(listVal[arr])
//}
//
//  
//  }
//}

//var co = 0;
// $navlist.each(function () { 
//   $(this).text(listVal[co]);
//   co = co + 1;
//   //alert(co)
//   if(co == row){
//     $(this).text(listVal[co])
//      $('this').append('</ul> <ul>');
//   co = co + 1;
//   }
//   
// });

})(jQuery);