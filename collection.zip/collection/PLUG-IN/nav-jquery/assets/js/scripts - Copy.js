(function($){
  // home page -------------------------------------------------------------- /
  
  /* --------------------menu functionality--------------------------- */
//   var containeroWidth = $('#nav').width();
//   var containerpadWidth = $('#nav').css('padding');
//   alert(containerpadWidth)
  var containerWidth = $('#nav_inner').width();
  //alert(containerWidth);
  var $navlist = $('#nav_inner').children('li')
  var listAll = $navlist.size();
  //alert(a);
  
  
  var m = [];
//  var listVal = [];
  var g = 0;
  var s = 0;
  var lv = 0;
  var count = 0;
  $navlist.each(function () {
          m[g] = $(this).width();
          
//           listVal[lv] = $(this).text();
          //alert(m[g]);
          s +=m[g];
//          alert('listVal[lv] ' + listVal[lv]);
        g++; 
        lv++;
        //if(s < containerWidth){
  //alert(s);
  //count++;
  //alert(count);
//}
    });
    //var y = m.length;
    var b;
    for (var w = 0; w < listAll; w++) {
        for (var E = 0; E < listAll; E++) {
            if (m[E] > m[E + 1]) {
                b = m[E];
                m[E] = m[E + 1];
                m[E + 1] = b
            }
        }
    }
 var maxWidth =  m[listAll - 1];
 alert(maxWidth)
$navlist.css('width',maxWidth); 
 var colm = Math.floor(containerWidth/maxWidth);
   alert('colm' + colm)
    //alert(listAll);
    var row =Math.floor(listAll/colm);
   alert('row' + row);
    
    //alert(listVal[0]);
    var lasts = [,];
    var c = 0;
    var fc =0;
    var sc = 1;
    var listVal = [,];
    $navlist.each(function () {
      var current_text = $(this).text();
        for (var fs = 0; fs < colm; fs++) {         
        for (var fE = 0; fE < row; fE++) {
//if(fc < colm){
//  alert('fc ' + fc);
//  alert('c ' + c);
          
          listVal[[fE][fs]] = current_text;
          //console.log(fE+" "+fs+" "+listVal[[fE][fs]]);

//          $(this).text(listVal[c]);
//          if(c = 1){
//          c = 1;
//          } else{
//          c = c + (row);
//          fc = fc +1;
//}else if(fc >= colm) {
//  alert('hi');
//   alert('fc' + fc);
//    alert('sc ' + sc);
//  $(this).text(listVal[sc]);
//  alert(sc);
//  sc = sc + row;
//  fc = fc +1;
//alert(fs + "  " +fE);
}
        }
        console.log(listVal);
        
//          }
          
//        }
//        }
    });
//alert(listAll/count-1);
})(jQuery);