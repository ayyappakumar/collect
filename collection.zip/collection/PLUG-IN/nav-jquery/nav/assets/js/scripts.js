(function($){
  /* --------------------menu functionality--------------------------- */

  var containerWidth = $('#nav_inner').width();
  var $navlist = $('#nav_inner').children('li');
  var $navheig = $navlist.height();
  var listAll = $navlist.size();
     
  /* =======Start: For finding Max-width =========*/
  var m = [];
  var g = 0;
  var s = 0;
  $navlist.each(function () {
    m[g] = $(this).outerWidth();
    s +=m[g];
    g++; 
  });
  var b;
  for (var w = 0; w < listAll; w++) {
    for (var E = 0; E < listAll; E++) {
      if (m[E] > m[E + 1]) {
        b = m[E];
        m[E] = m[E + 1];
        m[E + 1] = b
      }
    }
  }
  var maxWidth =  m[listAll - 1];
  $navlist.css('width',maxWidth); 
  /* ============================ End: ===============================*/ 
  
//For colume caculation
  var colm = Math.floor((containerWidth/(maxWidth + 2)));

//For row caculation
  var row =Math.round((listAll/colm)+.50);

/* =======Start: Condition for less than listitem 20 =========*/
  var open = false;
  if( listAll <= 20 && colm>=5){  
    colm = Math.floor(listAll/3);
    if(listAll>=10){
       row = 5;
    }else{
      row = 3;
    }
    open = true;
  }
   /* ============================ End: ===============================*/ 
var listheigh = $navheig*(row);
  var fc = 0;
  var sc = 0;
    $navlist.each(function () {      
      if(fc <= row){
        if(sc == 0){ 
          if(sc == 0 && fc == 0  ){
            $(this).addClass('column1 ');
          }else{
            $(this).addClass('column1');
          }
        }else if(sc == 1){
          if(sc == 1 && fc == 0  ){
            $(this).addClass('column2 reset');
            $(this).css('margin-top',"-"+listheigh);           
          }else{
            $(this).addClass('column2');
          }
        }else if(sc == 2){
          if(sc == 2 && fc == 0  ){
            $(this).addClass('column3 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column3');
          }
        }else if(sc == 3){
          if(sc == 3 && fc == 0  ){
            $(this).addClass('column4 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column4');
          }
        }else if(sc == 4){
          if(sc == 4 && fc == 0  ){
            $(this).addClass('column5 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column5');
          }
        }else if(sc == 5){
          if(sc == 5 && fc == 0  ){
            $(this).addClass('column6 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column6');
          }
        }else if(sc == 6){
          if(sc == 6 && fc == 0  ){
            $(this).addClass('column7 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column7');
          }
        }else if(sc == 7){
          if(sc == 7 && fc == 0  ){
            $(this).addClass('column8 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column8');
          }
        }else if(sc == 8){
          if(sc == 8 && fc == 0  ){
            $(this).addClass('column9 reset');   
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column9');
          }
        }else if(sc == 9){
          if(sc == 9 && fc == 0  ){
            $(this).addClass('column10 reset');       
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column10');
          }
        }else if(sc == 10){
          if(sc == 10 && fc == 0  ){
            $(this).addClass('column11 reset');
             $(this).css('margin-top',"-"+listheigh);
          }else{
            $(this).addClass('column11');
          }
        }
        fc = fc +1;
        if(fc == row){
          sc = sc + 1;
          fc = 0;
        }
      } 
    });
    $('#nav_inner').height(listheigh);
})(jQuery);